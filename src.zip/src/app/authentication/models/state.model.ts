export class StateModel
{
    public id;
    public name: string;
    public code: string;
    public status: string;
}