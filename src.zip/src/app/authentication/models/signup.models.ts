export class SignupModel
{
    public  firstname: string;
    public stateId:number;
    public mobile:number;
    public password: string;
    public email: string;
    public roleId:number;
}