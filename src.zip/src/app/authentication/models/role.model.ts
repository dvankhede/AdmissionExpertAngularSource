export class RoleModel
{
    public id;
    public name: string;
    public description: string;
    public status: string;
}